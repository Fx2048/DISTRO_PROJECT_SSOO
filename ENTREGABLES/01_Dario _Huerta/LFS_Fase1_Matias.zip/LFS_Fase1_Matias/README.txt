Proyecto: Linux From Scratch - Fase 1
Autor: Matías

Contenido:
- comandos_usados.sh: todos los comandos que se ejecutaron para preparar el entorno.
- salida_terminal.txt: verificación de entorno, directorios y herramientas instaladas.
- sources/: contiene los archivos descargados desde LFS.
- capturas/: carpeta vacía por si querés añadir imágenes del entorno.

Este paquete está listo para ser compartido con compañeros o profesores.
