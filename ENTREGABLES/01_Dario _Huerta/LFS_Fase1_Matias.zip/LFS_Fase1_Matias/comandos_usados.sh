#!/bin/bash
# Comandos ejecutados en la Fase 1 de LFS

# Establecer variable LFS
export LFS=/mnt/lfs

# Actualización del sistema
sudo apt update && sudo apt upgrade -y

# Instalación de paquetes base
sudo apt install -y build-essential bison gawk texinfo wget curl xz-utils zlib1g-dev libncurses-dev grub-pc patch flex git rsync xorriso

# Creación de estructura de directorios
sudo mkdir -pv /mnt/lfs/{sources,tools}
sudo chown -v $USER /mnt/lfs/{sources,tools}

# Variable de entorno persistente
echo 'export LFS=/mnt/lfs' >> ~/.bashrc
source ~/.bashrc
